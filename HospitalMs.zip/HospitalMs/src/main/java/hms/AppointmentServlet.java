package hms;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class AppointmentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String patientId = request.getParameter("patientId");
        String doctor = request.getParameter("doctor");
        String date = request.getParameter("date");
        String time = request.getParameter("time");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "root");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO appointments(patient_id, doctor, date, time) VALUES (?, ?, ?, ?)");
            ps.setString(1, patientId);
            ps.setString(2, doctor);
            ps.setString(3, date);
            ps.setString(4, time);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("appointment.html");
    }
}
