package hms;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class EHRServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String patientId = request.getParameter("patientId");
        String diagnosis = request.getParameter("diagnosis");
        String treatment = request.getParameter("treatment");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "root");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO ehr(patient_id, diagnosis, treatment) VALUES (?, ?, ?)");
            ps.setString(1, patientId);
            ps.setString(2, diagnosis);
            ps.setString(3, treatment);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("ehr.html");
    }
}
