package hms;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class BillingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String patientId = request.getParameter("patientId");
        String amount = request.getParameter("amount");
        String service = request.getParameter("service");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms", "root", "root");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO billing(patient_id, service, amount) VALUES (?, ?, ?)");
            ps.setString(1, patientId);
            ps.setString(2, service);
            ps.setString(3, amount);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("billing.html");
    }
}
